function logout(element){
    element.innerText = "Log out"
}
function hide(element){
    element.remove();
}