//A computer application needs to be able to identify if a written paragraph is written in First, Second, or Third Person

//1. write out 1 strategy that could be used to solve the problem 
//Identify by the keywoeds
//First person will include I/me/my/myself//we/us/our/ourselves
//Second person will include you
//Else will be Thire person

//2.create pseudo-code to apply one of the strategies to solve the problem
//Creating a function and use if, else if and else

//3.What is the hardest part of problem-solving? 
//The hardest part for me would be the NOTICE, it's the step that trying to see if my strategy work or needs to be adjueted. And if my strategy was not working, then have to start again and figure out another strategy.