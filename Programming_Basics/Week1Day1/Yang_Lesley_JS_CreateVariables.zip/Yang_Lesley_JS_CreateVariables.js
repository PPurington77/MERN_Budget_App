// height >= 42, tall needs to be at least 42inches
//age > 10, age needs to be over age 10

var height >= 42
var age > 10